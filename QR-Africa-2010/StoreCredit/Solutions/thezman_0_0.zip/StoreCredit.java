import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class StoreCredit {

	public void output(BufferedWriter out, int caseNum, String string) throws IOException{
		out.write("Case #" + caseNum + ": " + string + "\n");		
	}

	public void solve() throws IOException{
		
		Scanner in = new Scanner(new File("A-small-attempt0.in"));
		BufferedWriter out = new BufferedWriter(new FileWriter("A-small-attempt0.out"));
		int numCases = in.nextInt();
		for (int i = 0; i < numCases; i++) {
			
			int c = in.nextInt();
			int numItems = in.nextInt();
			
			ArrayList<Integer> items = new ArrayList<Integer>();
			for(int j = 0; j < numItems; j++){
				items.add(in.nextInt());
			}
			
			for(int j = 0; j < numItems - 1; j++){
				for(int k = j + 1; k < numItems; k++){
					if(items.get(j) +  items.get(k) == c){
						output(out, i+1, (j+1) + " " + (k+1));
					}
						
				}
			}
			
		}
		
		out.close();
	}
	
	public static void main(String[] args) throws IOException{
		StoreCredit s = new StoreCredit();
		s.solve();
		
	}

}


